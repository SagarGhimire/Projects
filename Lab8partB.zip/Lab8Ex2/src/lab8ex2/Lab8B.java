package lab8ex2;


/*
* Class: 44-241 Computer Programming II
* Author: Luke Carlson
* Description: Lab 8
* Due: 3/2/2017
* I pledge that I have completed the programming assignment independently.
I have not copied the code from a student or any source.
I have not given my code to any other student.
I have not given my code to any other student and will not share this code
with anyone under any circumstances.
 */
//package readfile1;

import java.io.File;
import java.util.Scanner;
import java.io.*;

public class Lab8B {
    public static void main(String[] args) throws FileNotFoundException {
        // create a Scanner object for reading
          Scanner keyboard = new Scanner(System.in);
        
         //OPEN the FILE FOR WRITING
         PrintWriter  outputFile = new PrintWriter ("Results.txt");
     
         int  numb;
         for (int i =1; i<=10; i++)
         {
              System.out.print("Enter Next Integer: ");
              numb = keyboard.nextInt();  // reading from  
              outputFile.println(numb); // write into file results.txt
              //System.out.println(numb);
         }
        // Close File
         outputFile.close();
    }
}

