/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8C;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author s527439
 */
public class Lab8C {

        public static void main(String[] args) throws FileNotFoundException {

        // Open the file.
        File file = new File("Names2.txt");
        Scanner inputFile = new Scanner(file);
        // Read until the end of the file.
        while (inputFile.hasNext()) {
            String str = inputFile.nextLine();  //read from file
            System.out.print(" " + str);   // print to a screen
        }
        String str = inputFile.nextLine(); 
        inputFile.close();// close the file when done
    }

}

