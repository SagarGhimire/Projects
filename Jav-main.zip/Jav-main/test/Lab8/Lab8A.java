package Lab8;

/*
* Class: 44-241 Computer Programming II
* Author: Luke Carlson
* Description: Lab 8
* Due: 3/2/2017
* I pledge that I have completed the programming assignment independently.
I have not copied the code from a student or any source.
I have not given my code to any other student.
I have not given my code to any other student and will not share this code
with anyone under any circumstances.
 */
//package readfile1;

import java.io.File;
import java.util.Scanner;
import java.io.*;

public class Lab8A {
    public static void main(String[] args) throws FileNotFoundException   {
         //OPEN the FILE FOR READING
         File   myfile = new File("FourNumbers4.txt");
         Scanner nextinputfile = new Scanner(myfile);
          int sum =0, numb;
         for (int i =1; i<=4; i++)
         {
              numb = nextinputfile.nextInt();
              sum = sum + numb;
         }
        System.out.println("The summation is: "+sum);
        nextinputfile.close();
    }
}

    
   


