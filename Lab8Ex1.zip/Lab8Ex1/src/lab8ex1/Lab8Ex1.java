/*
* Class: 44-241 Computer Programming II
* Author: Luke Carlson
* Description: Lab 8
* Due: 3/2/2017
* I pledge that I have completed the programming assignment independently.
I have not copied the code from a student or any source.
I have not given my code to any other student.
I have not given my code to any other student and will not share this code
with anyone under any circumstances.
 */
package lab8ex1;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.PrintWriter;

public class Lab8Ex1 {

    public static void main(String[] args) throws FileNotFoundException {
        File myfile = new File("lab8Data.txt");
        PrintWriter  outputFile = new PrintWriter ("Output.txt");       
        Scanner scanner = new Scanner(myfile);
        while(scanner.hasNextInt()){
            int i = scanner.nextInt();
            if(i % 2 == 0){
                outputFile.println((i + "    Even"));
            }
            else{
                outputFile.println((i + "    Odd"));
                
            }
        }
        outputFile.close();
    }
    
}
