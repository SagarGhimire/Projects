
package abstraction;
abstract class Parent{
 abstract public void doHomework(); //Abstract method no code
 public void method(){
     System.out.println("This is a method");
 }
    
}
 class Child1 extends Parent{
   public void doHomework(){
       System.out.println("Child 1 does homework");
   }
    
}
class Child2 extends Parent{
   public void doHomework(){
       System.out.println("Child 2 does homework");
   }}
   class Child3 extends Parent{
   public void doHomework(){
       System.out.println("Child 3 does homework");
   }
   }
public class Abstraction {
    public static void main(String[] args) {
        //You cannot create objects from an abstract class
       // Parent Obj = new Parent();
       Parent ch1 = new Child1(); //Polymorphism
       ch1.doHomework();
       Parent ch2 = new Child2();
       ch2.doHomework();
    }
    
}
