/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritencs;

/**
 *
 * @author S525189
 */
public abstract class xxx {
      int m_rows, m_cols;
  public abstract void set(int row, int col, int val);
  public abstract int get(int row, int col);

  public void print()
  {
    for (int i=0; i<m_rows; i++)
    {
      for (int j=0; j<m_cols; j++)
      {
          
        System.out.print(get(m_rows,m_cols) + " ");
      }
      System.out.println();
    }
  }
}

    
    

