package student;

/**
 *
 * @author s525189
 */
public class Student {
    int id;
String name;
String major;
public Student(int i, String n, String m){
    id = i;
    name = n;
    major = m;
    //Here I create the student constructor.
}
 @Override
 public String   toString()    // overriding the toString() method
 {         
  return id+"  "+name+"  "+major;  
}  

    /**
     * @param args the command line arguments
     */

    public static void main(String[] args) {
        // TODO code application logic here
        Student s1 = new Student(5892, "Zombie", "Astronomy");
        Student s2 = new Student(8923, "Zero", "Computer Science");
        //Here I create two student objects.
        
        System.out.println(s1.id);
        System.out.println(s1.name);
        System.out.println(s1.major);
        System.out.println(s2.id);
        System.out.println(s2.name);
        System.out.println(s2.major);
        //Here I print the attributes of each student object.
        
        System.out.println();
        System.out.println(s1); //jumbled mess of code memory address maybe?
        System.out.println(s2); //jumbled mess of code also memory address maybe?
       
        
        System.out.println(s1);
        System.out.println(s2);
        //Here I re-print s1 and s2, even though the override went through, 
        //it said to re-print in the instructions.
        
        
  System.out.println("HASHCODE of S1&S2  "+s1.hashCode()+"  "+s2.hashCode());
 //The hashcode is just a series of numbers, whereas normally, the value printed
 //by just printing the object, uses letters too, so it's still slightly different 
 //from just printing the objects, but it makes more sense this way.
    }
        
    

    }
        
    


