/*
 * Steps to create firsrt application
Step1: load the driver
type1 driver
class name: sun.jdbc.odbc.JdbcOdbcDriver
url: jdbc:odbc:dsn-name
 */
/* Step 2: Provide the content to database
 by using getConnection
*/


package adv.java;

/**
 *
 * @author s525189
 */
import java.util.*;
import java.lang.*;
import java.sql.*;
import java.sql.DriverManager;
import java.sql.SQLException;
public class ADVJava {


    
     // @param args the command line arguments
     
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        Class.forName("sun.jdbc.odbc.JdbcOdbcDriver"); //load the driver
        //step 2 connection to database
     // Connection con =   DriverManager.getConnection("url","username","password");
     Connection con =   DriverManager.getConnection("jdbc:odbc:Sagar","system","*********");
     Statement s = con.createStatement();
        System.out.println("Connection is created");
     
        
       
    }
    
  /*  static{
        System.out.println("Static class");
    }*/
}
