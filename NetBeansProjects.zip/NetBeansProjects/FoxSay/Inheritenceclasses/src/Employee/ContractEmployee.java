/*
* Class: 44-241 Computer Programming II
* Author: Terrence Hughes
* Description: HW5
* Due: 4/7/2017
* I pledge that I have completed the programming assignment independently.
I have not copied the code from a student or any source.
I have not given my code to any other student.
I have not given my code to any other student and will not share this code
with anyone under any circumstances.
 */
package Employee;

public class ContractEmployee extends Employee {

    private int contractPeriod;

    public void setContractPeriod(int cp1) {
        contractPeriod = cp1;
    }

    public int getContractPeriod() {
        return contractPeriod;
    }

    public double calContractPay() {
        double contractPay = 0;
        if (contractPeriod == 3) {
            contractPay = 7000.00;
        } else if (contractPeriod == 6) {
            contractPay = 15000.000;
        } else if (contractPeriod == 9) {
            contractPay = 25000.000;
        } else {
            System.out.println("Contract Period must be 3, 6, or 9 months.");
        }
        return contractPay;
    }

    public void displayRateType() {
        System.out.println("Sub class Contract Employee");
        System.out.println("Name: " + getName() + " id: " + getId() + " PayRate: " + getPayRate()
                + " PayType: " + getPayType());
        System.out.println("Contract Pay: " + calContractPay());
    }

}
