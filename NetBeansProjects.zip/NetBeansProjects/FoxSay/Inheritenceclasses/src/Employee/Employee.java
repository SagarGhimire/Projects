/*
* Class: 44-241 Computer Programming II
* Author: Terrence Hughes
* Description: HW5
* Due: 4/7/2017
* I pledge that I have completed the programming assignment independently.
I have not copied the code from a student or any source.
I have not given my code to any other student.
I have not given my code to any other student and will not share this code
with anyone under any circumstances.
 */
package Employee;

public class Employee {

    private String name;
    private int id;
    private double payRate;
    private String payType;

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    public double getPayRate() {
        return payRate;
    }

    public String getPayType() {
        return payType;
    }

    public void setName(String empName) {
        name = empName;
    }

    public void setId(int empId) {
        id = empId;
    }

    public void setPayRate(double empRate) {
        payRate = empRate;
    }

    public void setPayType(String empType) {
        payType = empType;
    }

    public void displayRateType() { //overriding
        System.out.println("Superclass Employee");
        System.out.println("Name: " + getName() + " id: " + getId() + " PayRate: " + getPayRate()
                + " PayType: " + getPayType());
        System.out.println("");
    }

    public static void main(String[] args) {
        Employee emp1 = new Employee();
        emp1.setId(123445);
        emp1.setName("Sagar");
        emp1.setPayRate(30000);
        emp1.setPayType("Full Time");
        System.out.println(emp1.getId() + " " + emp1.getName() + " " + emp1.getPayType() + " " + emp1.getPayRate());
        System.out.println("");

        HourlyEmployee emp2 = new HourlyEmployee();
        emp2.setId(174329);
        emp2.setName("Kali");
        emp2.setPayRate(15.75);
        emp2.setPayType("Part Time");
        emp2.setRate(2.7);
        emp2.setHours(20);
        System.out.println(emp2.getId() + " " + emp2.getName() + " " + emp2.getPayType() + " " + emp2.getPayRate());
        System.out.println("");

        ContractEmployee emp3 = new ContractEmployee();
        emp3.setId(523537);
        emp3.setName("Terrence");
        emp3.setPayRate(2800);
        emp3.setPayType("Full Time");
        emp3.setContractPeriod(6);
        System.out.println(emp3.getId() + " " + emp3.getName() + " " + emp3.getPayType() + " " + emp3.getPayRate());
        System.out.println("");
        emp1.displayRateType();

        emp2.displayRateType();
        emp3.displayRateType();

    }

}
