/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package foxsay;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author s525189
 */
public class FoxSay {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc=new Scanner(System.in);
        //List testCases = new ArrayList<>();
        int noOfCases = sc.nextInt();
       Map cases = new HashMap<Integer,String[]>();
       String st="";
       for(int i=1;i<=noOfCases;i++){
           
               st=sc.nextLine();
               st=sc.nextLine();
               String[] s = st.split(" ");
               System.out.println(st);
               System.out.println(s);
     cases.put(i, s);
           System.out.println(cases);
    }
       
       String lineCompare= "what does the fox say?";
       String line=sc.nextLine();
       while(sc.hasNext()&& !line.equalsIgnoreCase(lineCompare)){
           System.out.println(line);
           System.out.println(line.equalsIgnoreCase(lineCompare));
           String s[]= line.split(" ");
           int newLength=0;
           int actualLength=0;
           for(int i=1;i<=cases.size();i++){
               //int len = (cases.get(i).toString()).length();
               String[] comp = (String[]) cases.get(i);
               actualLength = comp.length;
               for(int j=0;j<comp.length;j++){
                   if(s[s.length-1].equalsIgnoreCase(comp[j])){
                       comp[j] = "qwerty";
                       newLength++;
                   }
               }
               String[] temp= new String[actualLength-newLength];
               int count=0;
               for(int j=0;j<comp.length;j++){
                   if(!comp[j].equals("qwerty")){
                       temp[count]=comp[j];
                       count++;
                   }
               }
               cases.replace(i, temp);
           }
           line=sc.nextLine();
       }
       String result = "";
       for(int i=1;i<=cases.size();i++){
           String[] comp = (String[]) cases.get(i);
           for(int j=0;j<comp.length;j++){
                   result+=comp[j]+" ";
               }
           result+= "\n";
       }
        System.out.println(result);
    }
    
    
}
