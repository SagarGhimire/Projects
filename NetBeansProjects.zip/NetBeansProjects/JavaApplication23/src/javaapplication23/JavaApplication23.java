/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication23;

/**
 *
 * @author s525189
 */
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
public class JavaApplication23 {

    /**
     * @param args the command line arguments
     */
   
        /* TODO code application logic here
        int numFrog, numLap, nextFrog, nextLap;
        Scanner keyb = new Scanner(System.in);
        System.out.print("Enter the total number of frogs(1-40): "); //user input number of frogs
        numFrog = keyb.nextInt();
        System.out.print("Enter the total number of laps(1-20): "); //user input number of laps 
        numLap = keyb.nextInt();
        //create a 2D array 
        int [][] arr = new int[numLap + 1][numFrog + 1];
        for (int i = 1; i <= numLap; i++) { //for loop of each row
            //user input frog numbers and distances
            System.out.print("Enter the next frog number and distance(use blank to separate): ");
            nextFrog = keyb.nextInt();
            nextLap = keyb.nextInt();
            for (int n = 1; n <= numFrog; n++) { //for loop of each column
                if (n == nextFrog) 
                    arr[i][n] = arr[i-1][n] + nextLap;  //add laps to previous scores          
                else 
                    arr[i][n] = arr[i-1][n]; //continue to count the scores
            }
        }
        //Determine the winner 
        int maxLap = arr[numLap-1][1]; //set max score 
        int maxFrog = 1; 
        for (int i = 1; i <= numFrog; i++) {
            if (arr[numLap-1][i] > maxLap) {
                maxLap = arr[numLap-1][i]; //compare final scores to get maximum lap 
                maxFrog = i; //get the winner
            }           
        }
        System.out.println("Winner: Frog#" + maxFrog);
        //Print the result 
        System.out.print("Frog:\t");
        for (int i = 1; i <= numFrog; i++) {
            System.out.print(i + " "); //print numbers of frogs
        }
        System.out.println();
        for (int i = 0; i < numLap; i++) {
            System.out.print("Lap  ");
            System.out.print(i + 1 + ": "); //print lap numbers
            for (int n = 1; n <= numFrog; n++) 
                System.out.print(arr[i][n] + " "); //print scores of each frog 
            System.out.println();
        }
        String j;
        for(int i =1; i<=100;i++){
            j = Integer.toString(i);
            
            if(i%3 == 0){
                j = "Fizz";
            }
            else if (i%5 ==0 ){
                j = "Buzz";}
            else if (i%3==0 && i%5 ==0){
                j = "FizzBuzz";
            }
            
            System.out.println(j);
        }
    }   
    }*/
        public static void main(String[] args) throws FileNotFoundException, IOException
    {
        //Reads in Sample Text File
        FileReader fileReader = new FileReader("sampleText.txt");
        BufferedReader br = new BufferedReader(fileReader);
        String text = "";
        String nextLine = br.readLine();

        while (nextLine != null)
        {
            text += nextLine;
            nextLine = br.readLine();
        }

        //Reads in texst to search for
        Scanner input = new Scanner(System.in);
        System.out.println("What would you like to search for?");
        String searchTerm = input.nextLine();

        //Returns number of comparisons for each search
        System.out.println("Simple Search:" + simpleSearch(searchTerm, text));
        System.out.println("BMH Search: " + bmhSearch(searchTerm, text));

    }

    //Takes in search term and the text to be searched, and returns number of comparisons.
    public static int simpleSearch(String searchTerm, String searchText)
    {
        int numComp = 0;
        int i = 0;
        while (i + searchTerm.length() <= searchText.length())
        {
            int j = 0;
            numComp += 1;
            while (searchText.charAt(i + j) == searchTerm.charAt(j))
            {
                if (j == 0)
                {
                    numComp -= 1;
                }
                j += 1;
                numComp += 1;
                if (j >= searchTerm.length())
                {
                    return numComp;
                }
            }
            i += 1;
        }

        return numComp;
    }

    //Takes in search term and the text to be searched, and returns number of comparisons.
    public static int bmhSearch(String searchTerm, String searchText)
    {
        char[] charPattern = searchTerm.toCharArray();
        char[] charText = searchText.toCharArray();
        int[] shift = makeShiftArray(charPattern);

        int numComp = 0;
        int i = 0;
        int j;
        while (i + charPattern.length <= charText.length)
        {
            j = charPattern.length - 1;
            numComp += 1;
            while (charText[i + j] == charPattern[j])
            {
                j -= 1;
                numComp += 1;
                if (j < 0)
                {
                    return numComp;
                }
            }
            i = i + shift[charText[i + charPattern.length - 1]];
        }
        return numComp;
    }

    //Generates shift array for search term.
    public static int[] makeShiftArray(char[] searchChar)
    {
        int[] shift = new int[256];
        for (int i = 0; i < shift.length; ++i)
        {
            shift[i] = searchChar.length;
        }
        for (int i = 0; i < searchChar.length - 1; ++i)
        {
            shift[searchChar[i]] = searchChar.length - 1 - i;
        }
        return shift;
    }
}

    
    

