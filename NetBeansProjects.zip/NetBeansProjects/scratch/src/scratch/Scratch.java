/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scratch;

/**
 *
 * @author S525189
 */
import java.util.*;
public class Scratch {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner in  = new Scanner(System.in);
        System.out.println("enter the number");
        int a = in.nextInt();
        add(a);
        
        // TODO code application logic here
    }
    public static void add(int num){
        String a = Integer.toString(num);
        String [] b = a.split(",");
      int e;
    
        for(String c : b){
            String f = c;
            int d = Integer.parseInt(f);
            d+=1;
            e=d;
            System.out.println(e);
            
        }
        
        
    
    }
}
