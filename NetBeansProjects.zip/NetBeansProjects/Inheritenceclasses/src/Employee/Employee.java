package Employee;

public class Employee {
private String name;
     private int id;
     private double payRate;
     private String payType;

    public String getName() {
        return name;
    }
    public int getId() {
        return id;
    }
    public double getPayRate() {
        return payRate;
    }
    public String getPayType() {
        return payType;
    }
    public void setName(String empName) {
        name = empName;
    }
    public void setId(int empId) {
        id = empId;
    }
    public void setPayRate(double empRate) {
        payRate = empRate;
    }
    public void setPayType(String empType) {
        payType = empType;
    }
    public void displayPayRate(){ //overriding
        System.out.println("Sub Employee");
         System.out.println("Name: " +getName() + " Id: " + id+ " PayRate: "+getPayRate()+ 
                " PayType: "+getPayType());
    }
    
     
    public static void main(String[] args) {
        Employee emp1 = new Employee();
        emp1.setId(123445);
        emp1.setName("Sagar");
        emp1.setPayRate(30000);
        emp1.setPayType("Full Time");
       
        HourlyEmployee emp2 = new HourlyEmployee();
        emp2.setTime(5);
         emp2.setId(174329);
        emp2.setName("Kali");
        emp2.setPayRate(15.75);
        emp2.setPayType("Part Time");
        
        
        ContractEmployee emp3 = new ContractEmployee();
        emp3.setId(991923);
        emp3.setName("Aziz");
        emp3.setPayRate(17.2);
        emp3.setPayType("Contract");
        emp3.setContractPeriod(3);
        emp1.displayPayRate();
        
        emp2.displayPayRate();
        
        emp3.displayPayRate();
    }
        
    }
   
    
    
    
    
    
    


    

