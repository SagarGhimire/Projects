
package Employee;

public class HourlyEmployee extends Employee{
 private int hours;
   
    public void setTime(int time){
        hours = time;
    }
    public int getTime(){
        return hours;
    }
    public double hourlyPayCheck(double payRate){
        double salary = payRate*hours;
        return salary;
    }
    @Override
    public void displayPayRate( ){
        System.out.println("Super class HourlyEmployee");
        System.out.println("Name: " +getName() + " Id: " + id+ " PayRate: "+getPayRate()+ 
                " PayType: "+getPayType()+" HourlyPay: "+hourlyPayCheck(getPayRate())+" The hours is: "+getTime());
        
        
    }
}



