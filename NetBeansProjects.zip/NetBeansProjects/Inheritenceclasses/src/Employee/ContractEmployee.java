
package Employee;


public class ContractEmployee extends Employee {
  private int contractPeriod;//Contract Period are in months
    public void setContractPeriod(int time){
       contractPeriod= time;
    }
    public int getContractPeriod(){
        return contractPeriod;
    }
    public double displayPayRate(int time){
        contractPeriod = time;
        double payRate =0;
        if (contractPeriod == 3){
            payRate = 7000.00;
            return payRate;
        }
        else if(contractPeriod == 6){
            payRate = 15000.00;
            return payRate;
        }
        else if (contractPeriod ==9){
            payRate = 25000.00;
            return payRate;
        }
        else{
            payRate = 0;
            return payRate;
        }
        
    }
    @Override
    public void displayPayRate(){
        System.out.println("Super class ContractPeriod");
        System.out.println("Name: " +getName() + " Id: " + getId()+ " PayRate: "+getPayRate()+ 
                " PayType: "+getPayType()+" PayRate : "+displayPayRate(getContractPeriod())+" with contract period time: "+getContractPeriod()+" months");
        if (getContractPeriod() ==0){
            System.out.println("The contract period should be 3,6,9 to get the payrate in the contract");
        }
    }
    }
    
        
    
    


    
    


    


    

