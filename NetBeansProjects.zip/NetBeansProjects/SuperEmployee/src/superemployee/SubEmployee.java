package superemployee;

public class SubEmployee extends SuperEmployee {

    String state;

    public String getState() {
        return state;
    }

    public void setState(String outstate) {
        state = outstate;
    }

}
