package superemployee;

public class SuperEmployee {

    int id;
    String name;
    double salary;

    public void setId(int Empid) {
        id = Empid;
    }

    public void setName(String Empname) {
        name = Empname;
    }

    public void setSalary(double Empsalary) {
        salary = Empsalary;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getSalary() {
        return salary;
    }

    public static void main(String[] args) {
        SuperEmployee Emp1 = new SuperEmployee();//Object of type superEmployee
        SubEmployee Emp2 = new SubEmployee();  //object of type subEmployee
        Emp2.setId(512551);
        Emp2.setName("Sagar");
        Emp2.setSalary(14000.0);
        Emp2.setState("MN");
        System.out.println("Id " + " " + Emp2.getId() + " Name: " + Emp2.getName() + " Salary: " + Emp2.getSalary()
                + " State " + Emp2.getState());
        // Emp1.setState("IO"); Parents cannot access the methods  and data of child

    }

}
