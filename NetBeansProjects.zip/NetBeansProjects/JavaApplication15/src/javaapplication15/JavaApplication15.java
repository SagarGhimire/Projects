/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication15;

/**
 *
 * @author s525189
 */
import java.util.*;
import static java.lang.Character.isAlphabetic;
import static java.lang.Character.isDigit;
import static java.lang.Character.isLowerCase;
import static java.lang.Character.isUpperCase;
import static java.lang.Character.isWhitespace;


public class JavaApplication15 {
    public static void main(String [] args){
  Random rand = new Random();
Scanner input = new Scanner(System.in);
System.out.println("Let the game begin!");
String p1_str, p2_str;
char p1, p2;
for(int i = 1; i < 27; i++){
System.out.println("Round " + i);
System.out.println("Enter Player 1's card");
p1_str = input.nextLine();
p1 = p1_str.charAt(0);
System.out.println("Enter Player 2's card");

p2_str = input.nextLine();
p2 = p2_str.charAt(0);
cardReader(p1, p2);
System.out.println();
}
}
public static void cardReader(char p1, char p2){
if(p1 < p2){
System.out.println("Player 1 is the winner!");
System.exit(0);
}
else if(p2 < p1){
System.out.println("Player 2 is the winner!");
System.exit(0);
}
else
System.out.println("Tie!");
}
    }
        
    
    

        
        






  /*  public static void main(String[ ] args){
        int arr[] = new int [7];
        int num = 5;
for(int index = arr.length-1;index>=0;index--){
      arr[index] = index*num;
       num+=5;
   }
   arr[0] = arr[2*3] + arr[0];
   arr[3] = arr[3]/arr[4];
  for(int i=0; i<arr.length;i++){
  System.out.println(arr[i]);
 // System.out.println(arr[2]);
  //System.out.println(arr[3]);
}
    }}


    /**
     * @param args the command line arguments
     
    public static void main(String[] args) { 
        int[] a = new int[6];
        Scanner input = new Scanner(System.in);
        for(int i=0;i<a.length;i++){
            System.out.println("Enter the number");
            int x= input.nextInt();
            a[i] = x;
              
           
        }
     int[] b = arr(a);
     for(int i=0;i<6;i++){
       System.out.println(b[i]);
     }
       
       
        
   
    }
    
    
    public static int[] arr(int num[]){
        for (int i=0;i<num.length;i++){
            num[i] = 3*i+4;
        }
        return num;
    }
    }
    
    


                   
   
    





/* System.out.println("grreater");
        else if(a>5)
            System.out.println("lower");
        else
            System.out.println("low");
       /* String d = "";
        while(a!=0){
            int b = a%2;
            String c = Integer.toString(b);
            
             d =c+d;
            a=a/2;
            
        }
        System.out.println("The binary form of the " +a+"is"+d);*/
