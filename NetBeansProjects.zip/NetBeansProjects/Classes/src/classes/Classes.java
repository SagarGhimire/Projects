package classes;

import java.util.Scanner;

public class Classes {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        StdInfo std = new StdInfo("Sagar", 99);
        StdInfo[] stds = new StdInfo[5];
        
       
        for(int i =0; i<stds.length;i++){
            System.out.println("Enter the name: ");
            String name = input.next();
            System.out.println("Enter the grade");
            double grade = input.nextDouble();
            stds[i] = new StdInfo(name, grade);
            
        }
        for(int i=0;i<stds.length;i++){
            System.out.println(stds[i]);
        }
        
    }

}
