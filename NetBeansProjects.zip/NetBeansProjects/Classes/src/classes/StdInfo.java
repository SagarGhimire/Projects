package classes;

/**
 *
 * @author s525189
 */
public class StdInfo {

    private String name;
    private double grade;

    //constructor
    public StdInfo(String n, double g) {
        name = n;
        grade = g;
    }

    public String getName() {
        return name;
    }

    public double getGrade() {
        return grade;
    }

}
