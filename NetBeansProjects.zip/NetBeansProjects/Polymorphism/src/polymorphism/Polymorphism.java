package polymorphism;
class A {
    public void method() {
        System.out.println("Method in class A");
    }
}
class B extends A {
 public void method() {
        System.out.println("Method in class B");
    }
}
public class Polymorphism {
    public static void main(String[] args) {
        // TODO code application logic here
        A obj1 = new A();
        obj1.method(); // Reference variable of type A pointing to an object of Type A
        System.out.println(obj1 instanceof A);
        System.out.println(obj1 instanceof B);
        // Polymorphism tells you that reference variable of A pointing to an object of type B
        A obj2 = new B(); 
       
        obj2.method();
        System.out.println(obj2 instanceof A);
        System.out.println(obj2 instanceof B);
        
        

    }

}
