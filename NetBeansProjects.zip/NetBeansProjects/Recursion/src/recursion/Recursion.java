/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recursion;

/**
 *
 * @author s525189
 */
public class Recursion {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        
        int  a[]= new int [4];
        a[0]=1;
        a[1] =2;
        a[2]=3;
        a[3]= 4;
        int d = sumArray(a,a.length-1);
        System.out.println(d);
    }
    public static int sumArray(int a[],int b){
        if(b==0){
            return a[0];
        }
        else{
          
           return sumArray(a,b-1)+a[b];
        }
        
    }
    
}
