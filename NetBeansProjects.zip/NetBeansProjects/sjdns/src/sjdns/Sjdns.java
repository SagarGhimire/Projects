/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sjdns;

/**
 *
 * @author S525189
 */

import javax.swing.JOptionPane;
import javax.swing.JFrame;
import javax.swing.*;
import java.util.Scanner;
import java.util.*;


public class Sjdns {


     
   
    public static void main(String[] args) {
        Random x = new Random();
        int size;
        int num;
        int idx;
       
        System.out.println("Enter the size of array");
        Scanner input = new Scanner(System.in);
        size = input.nextInt();
       
        int [] a= new int [size];
        for(int i=0;i<a.length;i++){
            a[i] = x.nextInt(20);
            System.out.println(a[i]);
        }
         System.out.println("Enter the number that is to be found");
        num = input.nextInt();
        idx = indexOf(a,num);
        System.out.println(idx);
            
        }
       public static int indexOf(int [] arr,int num ) {
        for( int i = 0 ; i < arr.length ; i++ ) {
            if( arr[i] == num ) { 
                return i;
            }
         }
         return -1;
     }
 }
        
   
    



        
    


    


    
    
    
        
    


        
    
   


   
        
   
    
    



    





    
    
        

    


// TODO code application logic here

