/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication24;

/**
 *
 * @author S525189
 */
public class Circle {
private double price;
  private char   reference;

  public   Circle(double newPrice, char newReference)
  {
    setPrice(newPrice);
    setLabel(newReference);
  }
 public void setPrice(double p){
      price = p;
}
public void setLabel(char ref){
reference = ref;
}


}






