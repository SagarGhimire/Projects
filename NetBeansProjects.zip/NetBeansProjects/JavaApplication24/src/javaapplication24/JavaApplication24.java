/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication24;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author s525189
 */
public class JavaApplication24 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
              
    }

}
    
    

       
      
    

//initiate two objects
/*Employee Karl = new Employee();
        Employee Jill = new Employee();
        
        //Setting information for Karl
        Karl.setfirstName("Karl");
        Karl.setlastName("Kinzley");
        Karl.sethourlyWage(11.89);
        
        //Setting information for Jill
        Jill.setfirstName("Jill");
        Jill.setlastName("Shroyer");
        Jill.sethourlyWage(14.56);
        
        //Getting and printing information for both employees
        System.out.println(Karl.getfirstName() + " " + Karl.getlastName() + " makes $" + Karl.getweeklyPay() + " per week");
        System.out.println(Jill.getfirstName() + " " + Jill.getlastName() + " makes $" + Jill.getweeklyPay() + " per week");  */

 /*  final int ARRAY_SIZE = 5;
        double[] x = new double[ARRAY_SIZE];
        for (int i = 1; i < ARRAY_SIZE; i++) {
            x[i] = 10.0;
        }

    }
}

/**
 * System.out.println("Enter the number: "); Scanner input = new
 * Scanner(System.in); int a = input.nextInt(); for(int i = 3; i <= a; i++){
 * boolean isprime = true;
 *
 * for(int j = 2; j < i; j++) { if(i % j == 0) // { isprime = false; break; } //
 * if(isprime == true){ System.out.println(i); // } }} }
 *
 *
 *
 * // TODO code application logic here
 */
