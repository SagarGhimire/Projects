
package classpracticesuper;

public class Insect {
    public  void eat(){
        System.out.println("Insects eat pollen");
    }
    
}
