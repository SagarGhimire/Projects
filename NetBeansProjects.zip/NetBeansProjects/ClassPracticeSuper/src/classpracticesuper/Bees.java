
package classpracticesuper;


public class Bees extends Insect{
    public void eat(){
        System.out.println("Bees eat nectar");
    }
    public void sting(){
        System.out.println("Bees sting");
    }
    public void work(){
        super.eat(); // invoke eat() of Insect
          eat(); // invoke eat() in bees
       
        System.out.println("Bees build hives");
    }
}
