
package classpracticesuper;


public class ClassPracticeSuper {

    public static void main(String[] args) {
        Bees honeybees = new Bees();
        honeybees.eat();
        honeybees.work();
        
    }
    
}
