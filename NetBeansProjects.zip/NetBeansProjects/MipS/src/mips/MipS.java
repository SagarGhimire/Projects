/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mips;

import java.util.Scanner;

/**
 *
 * @author s525189
 */
public class MipS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Enter the first number");
        int a = input.nextInt();
        System.out.println("Enter the first number");
        int b = input.nextInt();
        System.out.println("Enter the first number");
        int c = input.nextInt();
        System.out.println("Enter the first number");
        int d = input.nextInt();
        int n = 1;
        int max = 0;
        // while(n<5){
        if (b > max) {
            max = b;
        }
        else if (c > max) {
            max = c;

        }
        else if (d > max) {
            max = d;
        } else {
            max = a;
        }
        // }
        System.out.println(max);

    }

}
