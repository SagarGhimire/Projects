/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unionfind;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author s525189
 */
public class UnionFind {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc= new Scanner(System.in);
        int length = sc.nextInt();
        int noOfLines = sc.nextInt();
        List set = new ArrayList<Integer>();
        String st="";
        int first,second;
        while(noOfLines>0){
            switch(sc.next()){
                case "?": first = sc.nextInt();
                second=sc.nextInt();
                    if(set.isEmpty()){
                    if(first == second){
                        st=st+"yes\n";
                    }
                    else{
                        st=st+"no\n";
                    }
                }
                    else{
                        if(set.contains(first)&& set.contains(second))
                            st=st+"yes\n";
                        else
                            st=st+"no\n";
                    }
                    break;
                case "=":first = sc.nextInt();
                second=sc.nextInt();
                if(set.isEmpty()||(!(set.contains(first))&&!(set.contains(second)))){
                    set.add(first);
                    set.add(second);
                }
                else{
                    if(set.contains(first)){
                       set.add(second);
                    }
                    else{
                        set.add(first);
                    }
                }
            }
            noOfLines--;
        }
        System.out.println(st);
    }
    
}
