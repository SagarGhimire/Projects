
package democonstructor02;


public class Child extends Parent {
    private String a;
    public Child(String a){
       super(a); // This  invokes super  implicitly  eventhough it  isn't there
        System.out.println("This is a child constructor");
        
    }
    
}
