
package democonstructor02;


public class Parent {
    private String name;
    
    public Parent(){
        System.out.println("This is a parent Constructor");
    }
    public Parent(String b){
        name = b;
        System.out.println(name);
        
    }
}
