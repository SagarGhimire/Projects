
package democonstructor02;


public class DemoConstructor02 {

    public static void main(String[] args) {
        Child ch1 = new Child("Name");
        
    }
    
}
