/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examples;

/**
 *
 * @author S525189
 */
public class NewClass {
    private int number;
    private int max;
    private int min;
    private int sum;
    private double average;

    NewClass(int num, int maxm, int minm, int sume, double averaged) {
        number = num;
        max = maxm;
        min = minm;
        sum = sume;
        average = averaged;
    }
    public void setNumber(int num){
        number = num;
    }
    public void setMax(int maxu){
        max = maxu;
    }
    public void setMin(int minm){
        min = minm;
    }
    public void setSum(int sumd){
        sum = sumd;  
    }
    public void setAverage(int aveg){
        average = aveg;
    }
    public int getNumber(){
        return number;
    }
    public int getMax(){
        return max;
    }
    public int getMin(){
        return min;
    }
    public int getSum(){
        return sum;
    }
    public double getAverage(){
        return average;
    }
    public void declaring(){
        
    }

   
}

    
    
    

