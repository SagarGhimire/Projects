/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examples;

/**
 *
 * @author S525189
 */
public class name extends NewClass {

    private String firstName, lastName;

   public name(String fun, String lastn, int number, int max, int min, int sum, double average) {
        super(number, max, min, sum, average);
        firstName = fun;
        lastName = lastn;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
       this.lastName = lastName;
    }
    @Override
    public void declaring(){
        
    }

}
