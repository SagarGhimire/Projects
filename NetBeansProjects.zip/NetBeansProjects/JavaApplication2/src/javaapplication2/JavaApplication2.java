/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author s525189
 */
public class JavaApplication2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[][] M = new int[3][4];
        for (int i = 0; i < M.length; i++) {
            M[i][i] = i;
            int j = M[i].length - 1;
            for (j = 0; j < M[i].length; j++) {
                if (j != i) {
                    M[i][j] = i * j;
                }

                System.out.println(M[i][j]);
            }

            // TODO code application logic here
        }

    }
}
