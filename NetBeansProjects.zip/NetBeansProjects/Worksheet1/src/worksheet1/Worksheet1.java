/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package worksheet1;

/**
 *
 * @author s525189
 */
import java.util.*;

public class Worksheet1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[][] table = {{2, 5, 4, 7},
        {3, 1, 2, 9},
        {4, 6, 3, 0},};

        int[] sumOfColumns = colSum(table);
        int[] sum = new int[4];
        for (int x = 0; x < table.length; x++) {
            for (int y = 0; y < table[0].length; y++) {
                sum[y] += sumOfColumns[y];
            }
        }

        for (int i = 0; i < sum.length; i++) {
            System.out.println(sum[i]);
        }
    }

    public static int[] colSum(int[][] M) {

        int[] sum = new int[M[0].length];
        for (int y = 0; y < M.length; y++) {
            for (int x = 0; x < M[y].length; x++) {
                sum[x] += M[y][x];
            }
        }

        return sum;
    }

}
