/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primenumbers;

/**
 *
 * @author s525189
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class PrimeNumbers {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("lab8Data.txt");
       Scanner inputFile = new Scanner(file);
       Scanner keyboard = new Scanner(System.in);
       PrintWriter outputFile = new PrintWriter ("Results.txt");
       int counter = 0;
       while(inputFile.hasNext()){
           int num = inputFile.nextInt();
           counter++;
           if(num%2==1){
               outputFile.println(num + " Odd");
           }
           else{
               outputFile.println(num + " Even");
           }
       }
       outputFile.println("");
       System.out.println("The total number of items in lab8Data.txt is "+counter);
       inputFile.close();
       outputFile.close();
       
       
       System.out.println("Enter the size of the array: ");
       int count = keyboard.nextInt();
       System.out.println("Enter the lower bound(min): ");
       int min = keyboard.nextInt();
       System.out.println("Enter the upper bound(max): ");
       int max = keyboard.nextInt();
       
       int[] numbers = genArray(count, min, max);
       //System.out.println(numbers); I can't get the list to print...
       
       System.out.println("Enter a value to check: ");
       int a  = keyboard.nextInt();
       
       lastIndexOf(numbers,a);
       
       
      
       
    }
    
    public static int[] genArray(int size, int min, int max){
    int[] list = new int[size];
    Random number = new Random();
    for(int i = 0;i<list.length;i++){
            list[i] = number.nextInt(max)+min;
            System.out.println(list[i]);
            
        }
    
    System.out.println("");
    return list;
    }
    
    public static void lastIndexOf(int[] array, int a){
        int index = 0;
        for(int i = 0; i<array.length;i++){
            if(array[i]==a){
                index = i;
            }
            else{
                index = -1;
            }
        }
        System.out.println("The value "+a+" is at index "+index);
    }
}

/*   System.out.println("Enter a number to check the prime");
        Scanner input = new Scanner(System.in);
        int a = input.nextInt();
        String x = " ";
        String y =" ";
        int i = 0;
        int num = 0;
        String primeNumbers = " ";
        for (i = 1; i <= a; i++) {
            int counter = 0;
            for (num = i; num >= 1; num--) {
                if (i % num == 0) {
                    counter = counter + 1;
                }
            }
            if (counter == 2) {
                //Appended the Prime number to the String
                //primeNumbers = primeNumbers + i + " ";
                System.out.println(i);
            }
        }
        //System.out.println("The prime numbers are: " + primeNumbers);
    }
}

/* for(int i = 3; i<a;i++){
             int y =1;
            while(i-y>=2){
                int c = i/(i-y);
                if(c!=0){
                   int d = i;
                    System.out.println(d);
                }
                y++;
                
            }
        }
        
        // TODO code application logic here
    }
    
}*/
