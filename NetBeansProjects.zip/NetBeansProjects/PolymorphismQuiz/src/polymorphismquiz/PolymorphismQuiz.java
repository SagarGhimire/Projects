
package polymorphismquiz;
 class Shape{
     public void draw(){
         System.out.println("Drawing  shapes");
     }
 }
 class Circle extends Shape{
     public void draw(){
         System.out.println("Drawing  Circle");
     } 
 }
class Triangle extends Shape{
    public void draw(){
         System.out.println("Drawing Triangle");
     }
}
class Rectangle extends Shape{
    public void draw(){
         System.out.println("Drawing Rectangle");
     }
}
class Square extends Rectangle{
    public void draw(){
         System.out.println("Drawing Square");
     }
}
public class PolymorphismQuiz {
    public static void main(String[] args) {
        //Shape s = new Shape();
        //s.draw();
      //  Shape s = new Circle();
      Shape s;
      s = new Circle(); // Reference variable of type shape(superclass) points to an object of Circle(Subclass)
      s.draw();
      s = new Triangle();
      s.draw();
      //create recatangle and square
      Rectangle r = new Square();
      r.draw();
      // create an array of objects, circle, triangle, rec,
     Shape[ ] allShapes = new Shape[10];
     //fill allShapes 
     
      allShapes[0]  = new Circle();
      allShapes[1] = new Rectangle();allShapes[2] = new Circle();allShapes[3] = new Square();
      allShapes[4] = new Rectangle();allShapes[5] = new Circle();allShapes[6] = new Square();
      allShapes[7] = new Rectangle();allShapes[8] = new Circle();allShapes[9] = new Triangle();
      for(int i = 0; i<allShapes.length;i++){
          allShapes[i].draw();
      }
     
    }
    
}
