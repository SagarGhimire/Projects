
package students;


public  class FullTime extends Students {
    
     @Override
     public void doSomething(){ //override
        System.out.println("Do something in child class"); 
    }
    
}
