package students;

public class Students {
    private int id; //protected data fields are accessible to children but not to outside classes
    private double gpa;
    public int getId() {
        return id;
    }
    public double getGpa() {
        return gpa;
    }
    public void setId(int i) {
        id = i;
    }
    public void setGpa(double g) {
        gpa = g;
    }
    //Create two overloaded method and call them in main
    public void overloaded(double gpa){
        System.out.println("Overloaded method for gpa");
    }
    public void overloaded(int id){
        System.out.println("Overloaded method for id");
    }
    
   /* public  static void doSomething(){ //static method cannot be overriden
        System.out.println("Do something in parent class"); 
    }
    public  final void doSomething(){ //final method cannot be overriden
        System.out.println("Do something in parent class");}*/
    public   void doSomething(){ // overriden
        System.out.println("Do something in parent class");}

    public static void main(String[] args) {
        Students std1 = new Students ();
        FullTime std2 = new FullTime();
        std1.doSomething(); // std1 calls dosomething() in parent
        std2.doSomething(); //std2 calls dosomething() in child
        std1.overloaded(4.5); //overloading for gpa
        std1.overloaded(24823); //overloading for id
        
    }

}
