/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication16;

/**
 *
 * @author s525189
 */
import java.sql.*;
public class JavaApplication16 {
    public final void a(){
        
    }
    //overloading method if you have same method with two different paramaters
    public void m1(int i){
        System.out.println("int-args");
    }
    public void m1(float a){
        System.out.println("int-float");
    }
    //String and Object class
    //If the argument is valid for both child and parent then perference should be given to child 
    //child will get higer priority than parent
    public void m2(String s){
        System.out.println("String version");
    }
    public void m2(Object o){
        System.out.println("Object Version");
    }

    public static void main(String[] args) {
        JavaApplication16 a = new JavaApplication16();
        a.m1(5);
        a.m1(2.3f);
        a.m1('a');
        a.m1(5l);
        System.out.println("");
        a.m2("Sagar");
        a.m2(new Object());
        a.m2(null);
        // TODO code application logic here
       
    }
 
        
    }
    

