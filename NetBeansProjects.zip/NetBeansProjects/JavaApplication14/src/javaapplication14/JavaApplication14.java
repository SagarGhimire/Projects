/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication14;

import java.text.DecimalFormat;
import java.util.*;
import java.util.stream.IntStream;

/**
 *
 * @author s525189
 *
 */

public class JavaApplication14 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
 //a
          int c = 0;              //declaring variable
        Scanner key = new Scanner(System.in);
        
        String player1 = key.nextLine();   
        String p1 = player1.toUpperCase();      //converting to uppercase
  
        String player2 = key.nextLine();
        String p2 = player2.toUpperCase();
             if (p2.length()<26 || p1.length()<26) {
                System.out.println("\nYou didn\'t enter 26 inputs.");
                c = 26;
            }
            if (p2.length()>26 || p1.length()>26) {
                System.out.println("\nYou didn\'t enter 26 inputs.");
                c = 26;
            }

            
            
        while (c<26){               // Using While Loop
            char first = p1.charAt(c); 
            char second = p2.charAt(c);
            if (p1.equals(p2)){ 
            System.out.println("\nGame is tie.");     //Condition Statement
            break;
            
            }
            if (first < second) {
                System.out.println("\nPlayer Number 1 is the winner");
                break;              //Using Break
            }
            else if (first > second){
                System.out.println("\nPlayer Number 2 is the winner");
                break;                 //Using Break
            }
            c++;        //Incrementing count for loop or comparing each character
        }
    }
    

        




    
        
        
        
    


    
    
    
    /*int x = 5;
    int y = 5;
    while(x > 0){
        Random rand = new Random();
        char a = (char) (rand.nextInt(13) + 'a');
        char b = (char) (rand.nextInt(13) + 'a');
        p1 = p1 + a;
        p2 = p2 + b;
        
        if (a > b){
            System.out.println("Player Number 1 is the winner.");
            break;
            }
        if (b > a){
            System.out.println("Player Number 2 is the winner.");
            break;
            }
        x -= 1;
    }
        System.out.println(p1.toUpperCase());
        System.out.println(p2.toUpperCase());
}*/
    }}} public static void displayValues(int x,  int y){
        
    }
}



    



        
        
              
        
    
    


    
    


    /*  int [] a = new int[5];
            Scanner input  = new Scanner(System.in);
            System.out.println("enter the number you want to find the fib series");
            int n = input.nextInt();
            a[0] = 1;
            a[1] = 1;
            for(int i =0; i<n;i++){
                a.add(a[-1]+a[-2]);
            }
            
        
        }}
        
       /* System.out.println("Please enter the size of list you would like to sort: ");
        int size = input.nextInt();
        System.out.println("\t\tInsertion\tSelectAlgo\t Merge\t\t  BuiltIn");
        System.out.printf("%d\t\t%.10f    %.10f     %.10f     %.10f\n", size, timeInsertion(size), timeSelectAlgo(size), timeMerge(size), timeBuiltInSort(size)); 
    }
    
  /*  //insertion sort
    public static int insertionSort(ArrayList<Integer> L, int k) {
        for (int i = 0; i < L.size(); i++) { //iterating the list
            int j = i;
            while (j > 0 && L.get(j - 1) > L.get(j)) { //condition to swap
                swapInds(L, j, j - 1);

                j--; //decrease the index
            }
        }
        return L.get(k);
    }
    
    private static void swapInds(ArrayList<Integer> L, int i, int j) {
        Integer t = L.get(i);
        L.set(i, L.get(j));
        L.set(j, t);
    }

    public static ArrayList<Integer> mergeSort(ArrayList<Integer> L) {
        if (L.size() <= 1) {
            return L;
        }
        ArrayList<Integer> A = mergeSort(new ArrayList(L.subList(0, L.size() / 2))); //assigning the half of the list
        ArrayList<Integer> B = mergeSort(new ArrayList(L.subList(L.size() / 2, L.size()))); //assigning the rest half of the list
        return merge(A, B);//calling the merge function
    }

    private static ArrayList<Integer> merge(ArrayList<Integer> A, ArrayList<Integer> B) {
        int iA = 0;
        int iB = 0;
        ArrayList<Integer> C = new ArrayList<>();

        while (iA < A.size() && iB < B.size()) { //iterating until the size of the list

            if (A.get(iA) < B.get(iB)) { //condition to check the smallest element from the two list
                C.add(A.get(iA)); //adding the smallest element to the new list
                iA++; //increasing the index of the first list A

            } else {
                C.add(B.get(iB)); //adding the smallest element to the new list C
                iB++; //increasing the index of the list B
            }

        }
        while (iA < A.size()) {//add the value until the index is less than the length of array
            C.add(A.get(iA));
            iA++;
        }
        while (iB < B.size()) { //add the value until the index is less than the array
            C.add(B.get(iB));
            iB++;
        }
        return C;
    }
    
    public static int SelectAlgo(ArrayList<Integer>L,int k){
        int a = L.size();
        int b = a/2;
        ArrayList<Integer> Algo = new ArrayList<>();
        ArrayList<Integer> Algo1 = new ArrayList<>();
        ArrayList<Integer> Algo2 = new ArrayList<>();
        int c = L.get(b);
        for(int i= 0;i<L.size();i++){
            if(L.get(i)<c){
               Algo.add(c);
            }
            else if(L.get(i)>c){
                    Algo1.add(c);
                
            }
            else{
                Algo2.add(c);
            }
        }
        if(k<Algo.size()){
            return SelectAlgo(Algo,k);
        }
        else if(k< (Algo.size()+Algo2.size())){
            return L.get(b);
        }
        else{
            return SelectAlgo(Algo1,k-Algo.size()-Algo2.size());
        }
    }
    
    public static int builtInSort(ArrayList<Integer>L, int k){
        Collections.sort(L);
        return L.get(k);
    }
    
    public static ArrayList<Integer> randoList(int size) {
        ArrayList<Integer> C = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            C.add((int) (Math.random() * size * 2));
        }
        return C;
    }
    
    public static double timeInsertion(int size) {
        double avg = 0;
        for (int i = 0; i < 30; i++) {
            ArrayList<Integer> l = randoList(size);
            long start = System.nanoTime();
            insertionSort(l, l.size()/2);
            long end = System.nanoTime();
            avg += (end - start) / 1000000000.0;
        }
        return avg;
    }

    public static double timeMerge(int size) {
        double avg = 0;
        for (int i = 0; i < 30; i++) {
            ArrayList<Integer> l = randoList(size);
            long start = System.nanoTime();
            mergeSort(l);
            long end = System.nanoTime();
            avg += (end - start) / 1000000000.0;
        }
        return avg;
    }
    
    public static double timeSelectAlgo(int size) {
        double avg = 0;
        for (int i = 0; i < 30; i++) {
            ArrayList<Integer> l = randoList(size);
            long start = System.nanoTime();
            SelectAlgo(l,l.size()/2);
            long end = System.nanoTime();
            avg += (end - start) / 1000000000.0;
        }
        return avg;
    }
    
    public static double timeBuiltInSort(int size) {
        double avg = 0;
        for (int i = 0; i < 30; i++) {
            ArrayList<Integer> l = randoList(size);
            long start = System.nanoTime();
            builtInSort(l,l.size()/2);
            long end = System.nanoTime();
            avg += (end - start) / 1000000000.0;
        }
        return avg;
    }
}*/
// TODO code application logic here

