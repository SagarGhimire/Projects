
package javaapplication49;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JOptionPane;
import static java.lang.Character.*;
import javax.swing.JFrame;
import javax.swing.JPasswordField;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

class FinalExam {
    /**
     * List of right answers
1.	B   		6.  A		11. B		16. C
2.	D		7.  B		12. C		17. C
3.	A		8.  A		13. D		18. B
4.	A		9.  C		14. A		19. D
5.	C	        10.  D	       	15. D		20. A

     */
    private int correct = 0, wrong = 0;
    char[] realAnswers = {'B', 'D', 'A', 'A', 'C', 'A', 'B', 'A', 'C', 'D', 'B', 'C', 'D', 'A', 'D', 'C', 'C', 'B', 'D', 'A'};
    ArrayList<Integer> allWrong = new ArrayList<Integer>();
    public void rightOrwrong(char[] stdAnswers){
        for(int x = 0; x < stdAnswers.length; x++){
            if(stdAnswers[x] == realAnswers[x])
                correct += 1;
            else{
                wrong += 1;
                allWrong.add(x+1);
            }
        }
    }
    public boolean passedOrfailed(){
        if(correct <= 15){
            return false;
        }else{
            return false;
        }
    }
    
    public int correctAnswers(){
        return correct;
    }
    public int wrongAnswers(){
        return wrong;
    }
    public ArrayList<Integer> missedQuestions(){
        return allWrong;
    }
}


public class JavaApplication49 {
    
    //This is the original code before applying the swing library.

    /*public static void passwordChecker(String password){
        boolean upperCase = false;
        boolean digit = false;
        boolean flag = true;
        
        if(password.length() >= 8){
            for(int i = 0; i < password.length(); i++){   

                if(!Character.isLetterOrDigit(password.charAt(i)))
                    flag = false;

                if(Character.isUpperCase(password.charAt(i)))
                    upperCase = true;

                if(Character.isDigit(password.charAt(i)))
                    digit = true;
            }
        }
        else{
            System.out.println("Invalid Password Length");
        }
        if(upperCase && digit && flag){
            System.out.println("Correct Password");
        }
        else{
            System.out.println("Invalid Password");
        }
    }*/
     public static void main(String[] args) {
        
   FinalExam exam1 = new FinalExam();
        ArrayList<Integer> wrong = new ArrayList<Integer>();
        Scanner in = new Scanner(System.in);
        String input;
        char[] stdAnswer = new char[20];
        System.out.println("Enter your answers to the exam questions. (Make sure Caps Lock is ON!)");
        for(int x = 0; x < 20; x++){
            System.out.print("Question "+(x+1)+": ");
            input = in.nextLine();
            stdAnswer[x] = input.charAt(0);
            if(stdAnswer[x] != 'A'&&stdAnswer[x] != 'B'&&stdAnswer[x] != 'C'&&stdAnswer[x] != 'D'){
                System.out.println("ERROR: Valid answers are A, B, C, or D.");
                x--;
            }
        }
        exam1.rightOrwrong(stdAnswer);
        System.out.println("Correct Answers: " + exam1.correctAnswers());
        System.out.println("Incorrect Answers: " + exam1.wrongAnswers());
        if(exam1.passedOrfailed()){
            System.out.println("You passed the exam.");
        }else{
            System.out.println("You did not pass the multiple choice part of the  exam.");
        }
        wrong = exam1.missedQuestions();
        System.out.println("You missed the following questions:");
        for(int x = 0; x < wrong.size(); x++){
            System.out.print(wrong.get(x)+" ");
        }
    }

}