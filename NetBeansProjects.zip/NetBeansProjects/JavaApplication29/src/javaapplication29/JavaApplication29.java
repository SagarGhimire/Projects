/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication29;

import java.util.Random;

/**
 *
 * @author S525189
 */
public class JavaApplication29 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double start;
        double end;
        double gIncrease = 0.0, gRatio = 0.0, dp = 0.0;
        Random rand = new Random();
        Greedy g = new Greedy();
        Dynamic d = new Dynamic();
        //weight of the Knapsack that to be filled
        int W = 75;
        //Size of the items
        int n = 100;
        Item[] elements = new Item[n];
        for (int iter = 0; iter < 50; iter++) {

            for (int i = 0; i < elements.length; i++) {
                Item obj = new Item();
                obj.weight = rand.nextInt(W) + 1;
                for (int j = 0; j < i; j++) {
                    if (obj.weight == elements[j].weight) {
                        obj.weight = rand.nextInt(W) + 1;
                    }
                }
                obj.value = rand.nextInt(100);
                elements[i] = obj;
            }
            start = System.currentTimeMillis();
            g.greedyIncreaseWeight(elements, W);
            end = System.currentTimeMillis();
            gIncrease += (end - start);
            start = System.currentTimeMillis();
            g.greedySortRation(elements, W);
            end = System.currentTimeMillis();
            gRatio += (end - start);
            start = System.currentTimeMillis();
            d.dpKnapsack(elements, W);
            end = System.currentTimeMillis();
            dp += (end - start);
        }
        System.out.println("Time for greedyIncreasebyWeight " + gIncrease / 50);
        System.out.println("Time for greedyIncreasebyRatio " + gRatio / 50);
        System.out.println("Time for dynamicProgramming " + dp / 50);
    }

}

// TODO code application logic here

