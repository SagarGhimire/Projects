/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication29;

import java.util.Arrays;
import java.util.Comparator;

/**
 *
 * @author S525189
 */
public class Greedy {
    public void greedyIncreaseWeight(Item[] item , int W) {
       //sorting the array increasing weight
       Arrays.sort(item, new Comparator<Item>(){
           @Override
           public int compare(Item o1, Item o2) {
               return o1.weight - o2.weight; 
           }
       });
       
       double valueSum = 0.0;
       int weightSum = 0;
       double x = 0.0;
       double tempweight = 0.0;
       double tempval = 0.0;
       for(Item i : item){
          tempweight = i.weight;
          tempval = i.value;
          weightSum += i.weight;
          if(weightSum >= W) {
              break;
          }else {
              valueSum += i.value;
          }
       }
      double val = weightSum - tempweight;
      double additional = tempval /((W - val) / tempweight);
      valueSum += additional;
      System.out.println("value " + valueSum);
   }
    
   
   public void greedySortRation(Item[] item , int W){
     int[] ratio = new int[item.length];
    //Sorting the array based on the ratio.    
      Arrays.sort(item, new Comparator<Item>(){
          @Override
           public int compare(Item o1, Item o2) {
               return (o2.value/o2.weight) - (o1.value/o1.weight); 
           }
       });
      double[] x = new double[item.length];
      double tp = 0.0;
      int u = W;
      int i;
      for (i = 0; i < item.length; i++){
        x[i] = 0.0;
      }
     for (i = 0; i < item.length; i++) {
      if (item[i].weight > u)
         break;
      else {
         x[i] = 1.0;
         tp = tp + item[i].value;
         u = u - item[i].weight;
      }
   }
 
   if (i < item.length)
      x[i] = u / item[i].weight;
 
   tp = tp + (x[i] * item[i].value);
   System.out.println("\nMaximum profit is:"+ tp);
   }
}

   



