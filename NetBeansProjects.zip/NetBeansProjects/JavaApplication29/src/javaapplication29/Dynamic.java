/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication29;

/**
 *
 * @author S525189
 */
public class Dynamic {
    public int dpKnapsack(Item[] items, int W){
    int n = items.length;
    int[][] T = new int[n + 1][W+1];
    for(int col = 0 ; col <= W ; col++){ //[0, n-1]
        T[0][col] = 0;    // weight == 0
    }
    for(int row = 1 ; row <= n ; row++) {
            T[row][0] = 0;
    }
    for(int item = 1; item < n ; item++){
        for(int weight = 1;weight < W+1 ; weight++){
            if(items[item -1].weight <= weight){
                 T[item][weight] = Math.max(T[item-1][weight], items[item -1].value + T[item-1][weight-items[item - 1].weight]);
            }else {
              T[item][weight] = T[item-1][weight];   
            }
        }
    }
    return T[n - 1][W];
    }
}
    

