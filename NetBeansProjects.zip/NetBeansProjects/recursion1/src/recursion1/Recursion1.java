/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recursion1;

import static java.lang.Math.E;
import java.util.*;

/**
 *
 * @author S525189
 */
public class Recursion1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
       // System.out.println("Enter the number or string ");
        
        String a =input.next();
        //displayPermutation(a);
       // xMethod(5);
        // TODO code application logic here
       Recursion1 test = new Recursion1();
        System.out.println(test.toString());
    }
    public Recursion1() {
        Recursion1 test = new Recursion1();
    }
    /*public static void displayPermutation(String s){
        displayPermutation(" " , s);
        System.out.println(" "+s);
    }
    private static void displayPermutation(String s1, String s2){
        if(s2.isEmpty()){
            System.out.println(s1);
        }
        else{
            for(int i=0;i<s2.length();i++){
                displayPermutation(s1+s2.charAt(i),s2.substring(0,i)+ s2.substring(i+1,s2.length()));
                 
            }
            
        }
    }
    public static void xMethod(int n){
        if(n!=0){
             
            System.out.println(n);
            xMethod(n/10);
           
        }
    }*/

}
