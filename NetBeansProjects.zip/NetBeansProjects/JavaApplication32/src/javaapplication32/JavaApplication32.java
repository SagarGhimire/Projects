package javaapplication32;

import java.util.Scanner;

public class JavaApplication32 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // To find the index linear search
        /*Scanner s = new Scanner(System.in);
        int N = s.nextInt();
        int array[] = new int[N + 1];

        int M = s.nextInt();
        for (int i = 1; i < N + 1; i++) {
            array[i] = s.nextInt();
        }
        int found = 0;
        for (int j = 1; j < N + 1; j++) {
            if (array[j] == M) {
                found = j;
            }
        }
        System.out.println(found);*/

 /*Today, Monk went for a walk in a garden. There are many trees in the garden and each tree has an English alphabet on it. While Monk was walking, he noticed that all trees with vowels on it are not in good state. He decided to take care of them. So, he asked you to tell him the count of such trees in the garden. 
Note : The following letters are vowels: 'A', 'E', 'I', 'O', 'U' ,'a','e','i','o' and 'u'.

Input:
The first line consists of an integer 
T
T denoting the number of test cases.
Each test case consists of only one string, each character of string denoting the alphabet (may be lowercase or uppercase) on a tree in the garden.

Output:
For each test case, print the count in a new line.

Constraints:
 1≤T≤10
1≤length of string≤105

SAMPLE INPUT 
2
nBBZLaosnm
JHkIsnZtTL
SAMPLE OUTPUT 
2
1
Explanation
In test case 1, a and o are the only vowels. So, count=2*/
 /*Scanner s = new Scanner(System.in);
        int N = s.nextInt();
        
        String[] a = new String[N + 1];
        for (int i = 1; i < a.length; i++) {
            a[i] = s.next();}
         int i =1;
         while(i<a.length){
             int count =0;
            for(int j =0;j<a[i].length();j++){
             char x = a[i].charAt(j);
            if((x=='a'||x=='A') || (x=='e'||x=='E') || (x=='i'||x=='I') || (x=='o'||x=='O')||(x=='u'||x=='U')){
                count ++;  
            }
            
        }
            System.out.println(count);
            i++;
        
       

    }
    }
        Scanner a = new Scanner(System.in);
        int x = a.nextInt();
        int count = 0;
        int[] r = new int[x + 1];

        for (int i = 1; i < r.length; i++) {
            r[i] = a.nextInt();
        }
        int q = a.nextInt();
        int[] pow = new int[q];

        for (int j = 0; j < q; j++) {
            pow[j] = a.nextInt();
        }

        int i = 0;
        int total = 0;
        while (i < q) {
            for (int k = 0; k < r.length; k++) {
                if (pow[i] >= r[r.length - 1]) {
                    for (int l = 0; l < r.length; l++) {
                        total = total + r[l];

                    }
                    System.out.println(pow[i] + " " + total);
                }
                else if(pow[i]<=r[k]){
                    total = total+
                }
            }
            i++;
        }*/
        int a, b, c, i, sum;
        Scanner scan = new Scanner(System.in);

        c = 1;
        while (true) {

            a = scan.nextInt();
            b = scan.nextInt();
            if ((a == 0) && (b == 0)) {
                break;
            }
            if (a > b) {
                i = a;
                a = b;
                b = i;
            }
            sum = 0;
            if ((a != b) && (a + 1 != b)) {
                for (i = a + 1; i < b; i++) {
                    sum += i;
                }
            }
            System.out.printf("%d.  %d\n", c++, sum);
        }
    }
}
