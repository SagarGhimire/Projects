/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication32;

/**
 *
 * @author S525189
 */
public class TextBook {

    private double price;
    private char reference;

    public TextBook(double newPrice, char newReference) {
        setPrice(newPrice);
        setLabel(newReference);
    }

    public void setPrice(double p) {
        if(p>=18.5){
            price =p;
        }
        else{
            System.out.println("Your price should be greater than 18.5");
        }
    }

    public void setLabel(char ref) {
        if(ref=='A'|| ref=='B'){
            reference = ref;
        }
        else{
            reference ='B'; //default
        }
    }
    public double getPrice(){
        return price;
    }
    public char getref(){
        return reference;
    }
    public void ChangeRef(){
        if(reference=='A'){
            reference = 'B';
        }
        else if(reference == 'B'){
            reference = 'A';
        }
    }
    public int findTax(double taxrate){
        int total = (int)(taxrate*price);
        return total;
    }

}
