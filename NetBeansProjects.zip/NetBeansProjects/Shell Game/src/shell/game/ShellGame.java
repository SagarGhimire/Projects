/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shell.game;

/**
 *
 * @author s525189
 */
import java.util.*;
import java.io.*;
public class ShellGame {

    public static void main(String[] args) throws FileNotFoundException {
        String deck1, deck2;
    char char1, char2;
    boolean sameCard; 
    int sum1 = 0, sum2 = 0; 
    
    //Input Decks
    deck1 = "AABCBDEFDEFGGHHKLKIJLCJIMM";
    deck2 = "MMICJLJIKLFHGHGKEDFEDBCBAA";
    
    //Play the Game
    for(int i=0; i<deck1.length(); i++){
        char1 = deck1.charAt(i); 
        char2 = deck2.charAt(i);
        if (char1 == char2)
            System.out.println(char1 + " Against " + char2 + ", tie");
        if (char1 < char2){
            System.out.println(char1 + " Against " + char2 + ", Player 1 wins");
            sum1 += 1;
        }
        if (char2 < char1){
            System.out.println(char1 + " Against " + char2 + ", Player 2 wins");
            sum2 += 1; 
        }
    }
    //Create Header for Winner
    System.out.println();
    System.out.println("******************************");
    
    //Determine Winner
    if (sum1 > sum2)
        System.out.println("Player 1 is the Winner!!!");
    if (sum2 > sum1)
        System.out.println("Player 2 is the Winner!!!");
    if (sum1 == sum2)
        System.out.println("Player 1 and Player 2 Tied!!!");
    }}

        
        // TODO code application logic here
    
    
}
