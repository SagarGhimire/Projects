/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package staticnonstatic;


public class StaticNonStatic {
  private int grades;

    public int getGrades() {
        return grades;
    }

    public void setGrades(int g) {
        grades = g;
        testingStatic(); // calling static method to non static method
    }
    public static void testingStatic(){
        System.out.println("This is a method to test Static");
        
    }
    public static void main(String[] args) {
        // TODO code application logic here
        StaticNonStatic O1 = new StaticNonStatic();
        O1.setGrades(45);
        testingStatic(); // no need to create a object as it is static method
        StaticNonStatic.testingStatic(); // testingStatic belongs to Class
        O1.testingStatic(); // calling the method with object
        int []  a = new int [4];
    }
    
}
