/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9driver;

/**
 *
 * @author s525189
 */
public class Employee {
    private String firstName;
    private String LastName;
    private double hourlyWage;
    private double WeeklyWages;

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String LastName) {
        this.LastName = LastName;
    }

    public void setHourlyWage(double hourlyWage) {
        this.hourlyWage = hourlyWage;
        CalculatePay();
    }

    public void setWeeklyWages(double WeeklyWages) {
        this.WeeklyWages = WeeklyWages;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return LastName;
    }

    public double getHourlyWage() {
        return hourlyWage;
    }

    public double getWeeklyWages() {
        return WeeklyWages;
    }
     public void CalculatePay(){
         final int hours = 35;
         WeeklyWages = hours * hourlyWage;
                 
     }
    
    
    
}
