/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication25;

/**
 *
 * @author s525189
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.*;
public class JavaApplication25 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
          File myfile = new File("lab08.txt");
        PrintWriter  outputFile = new PrintWriter ("Output.txt");       
        Scanner scanner = new Scanner(myfile);
        while(scanner.hasNextInt()){
            int i = scanner.nextInt();
            if(i % 2 == 0){
                outputFile.println((i + "    Even"));
            }
            else{
                outputFile.println((i + "    Odd"));
                
            }
        }
        outputFile.close();
    }
    
}
    
}
