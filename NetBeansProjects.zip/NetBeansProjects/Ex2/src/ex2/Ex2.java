
/*
    * Class: 44-241 Computer Programming II
    * Author: Aziz Fellah
    * Description: Lab04(Random)
    * Due: 2/5/2017
    * I pledge that I have completed the programming assignment independently.
    I have not copied the code from a student or any source.
    I have not given my code to any other student.
    I have not given my code to any other student and will not share this code
    with anyone under any circumstances.
 */
package ex2;

import java.util.Random;
import java.util.Scanner;

public class Ex2 {

    public static void main(String[] args) {
        //EX.2
        double amountNum, count = 1;
    int range, evenCount=0, oddCount=0, maxNum=0, minNum=0, number;
    
    
    Scanner input = new Scanner(System.in);
    System.out.println("How many Random Numbers to be generated (Enter an"
            + " even number): ");
    amountNum = input.nextDouble();
    while (( amountNum % 2 ) != 0 )
        {
            System.out.println("Sorry, your number entered is not (even)"
                    + " please re-enter how many random numbers to be"
                    + " generated (Enter an even number): ");
            amountNum = input.nextDouble();
        }
    
    
    System.out.println("Enter the range from 0 ... 50: ");
    range = input.nextInt();
    minNum = range;
    System.out.println("---");
    
    while ( count <= amountNum)   
    {
        Random  randomNumbers = new Random( );
        number = randomNumbers.nextInt(range); 
        if (( number % 2 ) ==0 )
        {
            evenCount = evenCount + 1; 
        }
        else
        {
            oddCount = oddCount + 1;
        }
        if (number > maxNum)
        {
            maxNum = number;
        }
        if (number < minNum)
        { 
            minNum = number;
        }
        System.out.println(number);
         count++;
    }  
    
    System.out.println("---");
    System.out.println("There are " + evenCount + " Even Numbers");
    System.out.println("There are " + oddCount + " Odd Numbers");
    System.out.println();
    System.out.println("The maximum generated number is " + maxNum);
    System.out.println("The minimum generated number is " + minNum);
    
 //EX.3
  double num = 0, value = 0;
        
        do {
            if (num % 2 == 0) {
                value = value + 1.0 /(num * 2 + 1);
            } else {
                value = value - 1.0 /(num * 2 + 1);
            }
            num++;
        } while (num < 500000);

        System.out.println(value*4);
    
    
    }
    
}



        
        
      
        
        
        
        
        
    


