/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progcontest;

import java.util.Scanner;

/**
 *
 * @author s525189
 */
public class Progcontest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        int first, two, third;
        String st = "";
        String output = "";
       // while (sc.hasNext()) {
            first = sc.nextInt();
            two = sc.nextInt();
            third = sc.nextInt();
            //System.out.println("in while");
           // for (int i = 1; i <= 2; i++) {
          int i =1;
          if(first>0&&two>0&&third>0){
                switch (i) {
                    case 1:
                        if (first + two == third) {
                            st = first + "+" + two + "=" + third;
                        } else if (first - two == third) {
                            st = first + "-" + two + "=" + third;
                        } else if (first / two == third) {
                            st = first + "/" + two + "=" + third;
                        } else if (first * two == third) {
                            st = first + "*" + two + "=" + third;
                        }
                        else{
                            i++;}
                            
                        break;
                    case 2:
                        if (two + third == first) {
                            st = first + "=" + two + "+" + third;
                        } else if (two - third == first) {
                            st = first + "=" + two + "-" + third;
                        } else if (two * third == first) {
                            st = first + "=" + two + "*" + third;
                        } else if (two / third == first) {
                            st = first + "=" + two + "/" + third;
                        }
                        else
                        break;
                }
                System.out.println(st);
               /* if (!st.isEmpty()) {
                    output = output + "\n" + st;
                    st="";
                    break;
                }*/

            }}
        
       // System.out.println(output);
    }


