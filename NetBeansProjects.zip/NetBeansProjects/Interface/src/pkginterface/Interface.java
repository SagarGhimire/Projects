
package pkginterface;
interface I {
abstract void m1();
abstract void m2();
abstract void m3();
abstract void m4();
abstract void m5();
}
abstract class B implements I{
   public  void m1(){ System.out.println("method m1");}
   public  void m2(){ System.out.println("method m2");}
   public  void m3(){ System.out.println("method m3");}
   public  void m4(){ System.out.println("method m4");}
   public  void m5(){ System.out.println("method m5");}
    
}
class C extends B{
    
}

public class Interface {

    
    public static void main(String[] args) {
        // TODO code application logic here
        B obj1 = new C();
        obj1.m1();
        obj1.m2();
        obj1.m3();
        obj1.m4();
        obj1.m5();
        
    }
    
}
