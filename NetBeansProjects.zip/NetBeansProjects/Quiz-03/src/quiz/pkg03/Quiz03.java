
package quiz.pkg03;
import java.util.ArrayList;
class Student{
    private String FName = null;
    private String LName = "";
    private int id =0 ;
public Student(String fn, String ln, int i){
    FName  = fn;
    LName = ln;
    id =i;  
}
}
public class Quiz03 {

    public static void main(String[] args) {
      ArrayList <String> list = new ArrayList<String>();
      ArrayList <Student> std = new ArrayList<Student>(); //arraylist of student class
      ArrayList <Integer> list1 = new ArrayList<Integer>();
      String str2 = new String ("Sumnima");
      list.add("Sagar"); list.add("Aziz"); list.add("Hannah"); list.add("Caleb"); list.add(str2);
      list1.add(5);  list1.add(50);  list1.add(25);  list1.add(500);
      Student std1 = new Student("Sanam","Malla",78);
      std.add(std1);
      std.add(new Student("Sa","Mal",7));
     
      for(int i =0; i<list1.size();i++){     
          if(i%2==0) //even
              list1.add(i+1);
          else      //odd
              list1.remove(i);
          
      }
       for(int j=0; j<list1.size();j++)
           System.out.println(list1);
           System.out.println(list1.size());
       
    }
    
}
